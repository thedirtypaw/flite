import article from './article'

export const schemaTypes = [article]
