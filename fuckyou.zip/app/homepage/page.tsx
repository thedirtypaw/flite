import FliteProtein from '../../components/fliteProtein/FliteProtein';

export default async function Homepage() {
  return (
    <main className="min-h-screen flex flex-col">
      {/* Reserve top space for content */}
      <section className="flex-grow flex flex-col justify-start">
        <FliteProtein />
      </section>
    </main>
  );
}