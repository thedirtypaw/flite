
import KnowledgePage from '../../components/fliteProtein/KnowledgePage';

export default async function Knowledge() {
  return (
    <main className="min-h-screen flex flex-col">
      {/* Reserve top space for content */}
      <section className="flex-grow flex flex-col justify-start">
        <KnowledgePage />
      </section>
    </main>
  );
}