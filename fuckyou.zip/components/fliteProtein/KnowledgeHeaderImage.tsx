'use client';

export default function KnowledgeHeaderImage() {
  return (
    <img
      src="/grafica_bonsai.png"
      alt="Knowledge Hero Graphic"
      className="w-full max-w-md h-auto"
    />
  );
}
